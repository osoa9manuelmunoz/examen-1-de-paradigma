﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace examen_manuel_muñoz_paradigma
{
    public partial class Form1 : Form
    {
        public void FormularioNuevo(string tipoUsuario)
        {
            Form fromcargando;
            if(tipoUsuario == "administrador") 
            { 
                fromcargando = new Form2(); 
            }
            else
            { 
                fromcargando = new Form3(); 
            }

            this.Hide();
            fromcargando.Show();
        }
   
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void contraseña_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("solo numeros");
                e.Handled = true;
                return;
            }
        }

        private void usuario_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 64) || (e.KeyChar >= 91 && e.KeyChar <= 96) || (e.KeyChar >= 123 && e.KeyChar <= 255))
            {
                MessageBox.Show("solo letras");
                e.Handled = true;
                return;
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((usuario.Text == "sandra") && (contraseña.Text == "321"))
            {
                FormularioNuevo("administrador");
            }
            else if ((usuario.Text == "dayana") && (contraseña.Text == "123"))
            {
                FormularioNuevo("Usuario");
            }
            else if ((usuario.Text == "maria") && (contraseña.Text == "123"))
            {
                FormularioNuevo("Usuario");
            }
            else if ((usuario.Text == "luisa") && (contraseña.Text == "123"))
            {
                FormularioNuevo("Usuario");
            }
            else if ((usuario.Text == "carolina") && (contraseña.Text == "123"))
            {
                FormularioNuevo("Usuario");
            }
            else if ((usuario.Text == "maria") && (contraseña.Text == "123"))
            {
                FormularioNuevo("Usuario");
            }
            else
            {
                MessageBox.Show("revise bien el usuario y contraseña ");
            }
        }

 
    }
}
