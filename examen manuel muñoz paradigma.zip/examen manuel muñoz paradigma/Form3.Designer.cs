﻿
namespace examen_manuel_muñoz_paradigma
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.cantidad1 = new System.Windows.Forms.TextBox();
            this.cantidad2 = new System.Windows.Forms.TextBox();
            this.cantidad3 = new System.Windows.Forms.TextBox();
            this.cantidad4 = new System.Windows.Forms.TextBox();
            this.cantidad5 = new System.Windows.Forms.TextBox();
            this.nombrecliente = new System.Windows.Forms.TextBox();
            this.documento = new System.Windows.Forms.TextBox();
            this.ingresar = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(36, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tipos de pan :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(175, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Formulario de venta";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(65, 100);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "aliniados cuantos";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(68, 146);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "no aliniados cuantos";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(68, 203);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "especiales cuantos ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(68, 275);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(105, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "total panes vendidos";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(315, 275);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "total valor";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(68, 356);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(95, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Nombre del cliente";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(208, 356);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(62, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "Docmuneto";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(338, 356);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(30, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Hora";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(300, 99);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(40, 13);
            this.label11.TabIndex = 10;
            this.label11.Text = "$1.000";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(303, 145);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(31, 13);
            this.label12.TabIndex = 11;
            this.label12.Text = "$500";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(300, 203);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(40, 13);
            this.label13.TabIndex = 12;
            this.label13.Text = "$2.000";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // cantidad1
            // 
            this.cantidad1.Location = new System.Drawing.Point(195, 100);
            this.cantidad1.Name = "cantidad1";
            this.cantidad1.Size = new System.Drawing.Size(100, 20);
            this.cantidad1.TabIndex = 13;
            this.cantidad1.TextChanged += new System.EventHandler(this.cantidad1_TextChanged);
            this.cantidad1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cantidad1_KeyPress);
            // 
            // cantidad2
            // 
            this.cantidad2.Location = new System.Drawing.Point(195, 145);
            this.cantidad2.Name = "cantidad2";
            this.cantidad2.Size = new System.Drawing.Size(100, 20);
            this.cantidad2.TabIndex = 14;
            this.cantidad2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cantidad2_KeyPress);
            // 
            // cantidad3
            // 
            this.cantidad3.Location = new System.Drawing.Point(195, 203);
            this.cantidad3.Name = "cantidad3";
            this.cantidad3.Size = new System.Drawing.Size(100, 20);
            this.cantidad3.TabIndex = 15;
            this.cantidad3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cantidad3_KeyPress);
            // 
            // cantidad4
            // 
            this.cantidad4.Location = new System.Drawing.Point(71, 308);
            this.cantidad4.Name = "cantidad4";
            this.cantidad4.Size = new System.Drawing.Size(100, 20);
            this.cantidad4.TabIndex = 16;
            this.cantidad4.TextChanged += new System.EventHandler(this.cantidad4_TextChanged);
            this.cantidad4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cantidad4_KeyPress);
            // 
            // cantidad5
            // 
            this.cantidad5.Location = new System.Drawing.Point(334, 311);
            this.cantidad5.Name = "cantidad5";
            this.cantidad5.Size = new System.Drawing.Size(100, 20);
            this.cantidad5.TabIndex = 17;
            this.cantidad5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cantidad5_KeyPress);
            // 
            // nombrecliente
            // 
            this.nombrecliente.Location = new System.Drawing.Point(71, 385);
            this.nombrecliente.Name = "nombrecliente";
            this.nombrecliente.Size = new System.Drawing.Size(100, 20);
            this.nombrecliente.TabIndex = 18;
            this.nombrecliente.TextChanged += new System.EventHandler(this.nombrecliente_TextChanged);
            this.nombrecliente.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.nombrecliente_KeyPress);
            // 
            // documento
            // 
            this.documento.Location = new System.Drawing.Point(211, 385);
            this.documento.Name = "documento";
            this.documento.Size = new System.Drawing.Size(100, 20);
            this.documento.TabIndex = 19;
            this.documento.TextChanged += new System.EventHandler(this.documento_TextChanged);
            this.documento.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.documento_KeyPress);
            // 
            // ingresar
            // 
            this.ingresar.Location = new System.Drawing.Point(178, 470);
            this.ingresar.Name = "ingresar";
            this.ingresar.Size = new System.Drawing.Size(133, 23);
            this.ingresar.TabIndex = 21;
            this.ingresar.Text = "vender producto";
            this.ingresar.UseVisualStyleBackColor = true;
            this.ingresar.Click += new System.EventHandler(this.ingresar_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "PM",
            "AM"});
            this.comboBox1.Location = new System.Drawing.Point(410, 383);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(52, 21);
            this.comboBox1.TabIndex = 22;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(315, 311);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(13, 13);
            this.label14.TabIndex = 23;
            this.label14.Text = "$";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(341, 383);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(63, 20);
            this.textBox1.TabIndex = 24;
            this.textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(472, 554);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.ingresar);
            this.Controls.Add(this.documento);
            this.Controls.Add(this.nombrecliente);
            this.Controls.Add(this.cantidad5);
            this.Controls.Add(this.cantidad4);
            this.Controls.Add(this.cantidad3);
            this.Controls.Add(this.cantidad2);
            this.Controls.Add(this.cantidad1);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button ingresar;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox cantidad1;
        private System.Windows.Forms.TextBox cantidad2;
        private System.Windows.Forms.TextBox cantidad3;
        private System.Windows.Forms.TextBox cantidad4;
        private System.Windows.Forms.TextBox cantidad5;
        private System.Windows.Forms.TextBox nombrecliente;
        private System.Windows.Forms.TextBox documento;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox1;
    }
}