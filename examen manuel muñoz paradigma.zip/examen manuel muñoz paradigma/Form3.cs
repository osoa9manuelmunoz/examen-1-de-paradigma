﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace examen_manuel_muñoz_paradigma
{
    public partial class Form3 : Form
    {
        
        public Form3()
        {
            InitializeComponent();
        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void cantidad1_TextChanged(object sender, EventArgs e)
        {

        }

        private void cantidad1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("solo numeros");
                e.Handled = true;
                return;
            }
        }

        private void cantidad2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("solo numeros");
                e.Handled = true;
                return;
            }
        }

        private void cantidad3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("solo numeros");
                e.Handled = true;
                return;
            }
        }

        private void cantidad4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("solo numeros");
                e.Handled = true;
                return;
            }
        }

        private void cantidad5_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 37 && e.KeyChar <= 35)||(e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("solo numeros");
                e.Handled = true;
                return;
            }
        }

        private void nombrecliente_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 64) || (e.KeyChar >= 91 && e.KeyChar <= 96) || (e.KeyChar >= 123 && e.KeyChar <= 255))
            {
                MessageBox.Show("solo letras");
                e.Handled = true;
                return;
            }
        }

        private void documento_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("solo numeros");
                e.Handled = true;
                return;
            }

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void ingresar_Click(object sender, EventArgs e)
        {
            string hora = textBox1.Text,
                   horas = comboBox1.SelectedItem.ToString(),
                   Nombrecliente = nombrecliente.Text,
                   Documento = documento.Text,
                   pan1 = cantidad1.Text,
                   pan2 = cantidad2.Text,
                   pan3 = cantidad3.Text,
                   pan4 = cantidad4.Text,
                   pan5 = cantidad5.Text;


            MessageBox.Show(String.Format("la venta fue un exito:\n" +

                "hora de la venta {0} \n" + "{1}\n " +

                "Nombre del Cliente: {2} \n" +

                "Documento del Cliente: {3} \n" +

                "pan lineado: {4} \n" +

                "pan normal: {5} \n" +

                "pan especial: {6} \n" +

                "cantidad de pan : {7} \n" +

                "valor total $ : {8}\n"
                ,hora,horas,Nombrecliente, Documento,pan1,pan2,pan3,pan4,pan5));
        }

        private void cantidad4_TextChanged(object sender, EventArgs e)
        {

        }

        private void nombrecliente_TextChanged(object sender, EventArgs e)
        {

        }

        private void documento_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("solo numeros");
                e.Handled = true;
                return;
            }
        }
    }
}
